num1 = 10
num2 = 13

firstName = "Naeem"
lastName = "Yeager"

sumNum = num1 + num2 


# The following statements are all valid examples of how to print strings 

print 'This is also a string'
print 'He said "Hello"'
print "Naeem's String"
print "This is a string"
print "The sum of the first number %s and the second number %s is: %s!" %(num1, num2, sumNum,)
print firstName + " " + lastName
print "Hello, " + firstName + " " + lastName + ", you are number %s" %num1