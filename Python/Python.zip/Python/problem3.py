objPrice = raw_input("How is the item?: ")

objPrice = float(objPrice)

divisible = (100*objPrice)%5

print divisible  














