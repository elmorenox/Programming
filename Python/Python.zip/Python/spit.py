example = '2343'
numberString = '123456789011'

size = len(example)

print size


a = numberString[:1]
b = numberString[1:3]

c = numberString[:2]

print a
print b
print c