num_str1 = raw_input('Please enter an integer:')  # hi mom
num_str2 = raw_input('Please enter a floating point number:')

str1_int = int(num_str1)
str2_float = float(num_str2)  # this is a  comment

print 'The numbers are: ',str1_int,' and ',str2_float
print 'Their sum is:',str1_int+str2_float, 'and their product is:',str1_int*str2_float
