num1 = 12
num2 = 10

if num1 > num2:
	print "%s is greater than %s" %(num1, num2)

elif num2 > num1:
	print "%s is greater than %s" %(num2, num1)

else:
	print "%s and %s are equal" %(num1, num2)
		