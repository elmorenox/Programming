a = "a"
b = "b"
c = "c"

print a
print b
print c

a = b

print a


