# Assign some Boolean variables
a = True
b = False
print ('a=', a, 'b="', b)

# Reassign a 
a = False; 
print ('a=', a, 'b=', b)