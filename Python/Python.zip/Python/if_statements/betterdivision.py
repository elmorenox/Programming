# Get two integers from the user
dividend = float(input("Please enter a number to divide: "))
divisor = float(input("Please enter the second number to divide: "))
# If possible, divide them and report the result
if divisor != 0:
	print(dividend, '/', divisor, '=', dividend/divisor)

