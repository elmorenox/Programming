userInput = 1234

reverse = str(userInput)[::-1]

print userInput
print reverse