userNum = input("Please enter a number: ")

userNum = userNum + 1

for number in range(1, userNum):
	print number
