numberList = [1,2,3,4,5,6,7,8,9,10]
namesList = ["Falon", "Jackie", "Sana", "Marvin", "Kemi"]



for number in numberList: 
	print number