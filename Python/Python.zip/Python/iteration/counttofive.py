count = 1				#	Initialize counter
while count <= 5: 		#	Should we continue?
	print (count)		#	Display counter, then
	count += 1			# 	Increment counter
