# Exercise: ForCount.py 
''' 
Write a program that gets an integer from the user
and counts to that number.

'''

userNum = input("Please enter a number: ")

for number in range(userNum):
	print number + 1
