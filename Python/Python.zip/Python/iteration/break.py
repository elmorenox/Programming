entry = 0 
numSum = 0 

while True:
	print ("Enter numbers to add, negative number will end list: ") 
	entry = input()
	break
	numSum += entry
print "Sum =", numSum
