#	Allow the user to enter a sequence of non-negative number

entry = 0 		# Ensure the loop is entered
numSum = 0 		# Initialize sum 